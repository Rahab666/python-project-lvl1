from brain_games.games import progression_game_logics


def main():
    """Start brain progression game"""

    progression_game_logics.progression_game()


if __name__ == '__main__':
    main()
