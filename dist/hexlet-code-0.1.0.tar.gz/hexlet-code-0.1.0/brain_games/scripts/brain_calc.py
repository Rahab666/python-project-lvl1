#!/usr/bin/env python
from brain_games.games import calc_game_logics


def main():
    """Start brain even game"""

    calc_game_logics.calc_game()


if __name__ == '__main__':
    main()
