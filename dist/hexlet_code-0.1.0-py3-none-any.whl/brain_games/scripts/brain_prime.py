from brain_games.games import prime_game_logics


def main():
    """Start brain prime game"""

    prime_game_logics.prime_game()


if __name__ == '__main__':
    main()
