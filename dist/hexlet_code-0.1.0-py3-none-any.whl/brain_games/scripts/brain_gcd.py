from brain_games.games import gcd_game_logics


def main():
    """Start brain gcd game"""

    gcd_game_logics.gcd_game()


if __name__ == '__main__':
    main()
